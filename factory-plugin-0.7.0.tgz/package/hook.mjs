#!/usr/bin/env node

// packages/harness-kit/src/hook/main.ts
import { realpathSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";

// packages/harness-kit/src/strings.es.ts
var strings = {
  hook: {
    usage: "Uso: factory-hook <harness> <evento> | factory-hook watch --harness <id> | factory-hook probe",
    runtimeDown: "El runtime no responde. El evento queda en el spool y el harness sigue.",
    spoolDropped: (count) => `Se descartaron ${count} eventos antiguos del spool (l\xEDmite 20 MiB).`,
    probeFailed: "factory-hook probe no alcanz\xF3 el runtime.",
    payloadInvalid: "El payload del hook no es JSON v\xE1lido.",
    stdinTruncated: "El payload super\xF3 1 MiB y se trunc\xF3.",
    responseInvalid: "El runtime respondi\xF3 sin un HookResponse v\xE1lido.",
    failed: "factory-hook no pudo terminar y deja seguir al harness.",
    startSpawned: "Se intent\xF3 arrancar el runtime en segundo plano.",
    startSkipped: "No se arranc\xF3 el runtime porque FACTORY_NO_AUTOSTART est\xE1 activo.",
    startMissing: "No hay un comando de arranque del runtime en esta m\xE1quina."
  },
  install: {
    foreignMarkdown: (path) => `No se sobrescribe ${path}: no tiene la cabecera de Factory. Se guard\xF3 una copia .factory-backup.`,
    invalidJson: (path) => `No se fusiona ${path}: el JSON no se puede leer. Se guard\xF3 una copia .factory-backup.`,
    commandFailed: (command, code) => `El comando \xAB${command}\xBB termin\xF3 con c\xF3digo ${code}.`,
    outsideHome: "La ruta de instalaci\xF3n queda fuera del directorio personal.",
    badHarness: "El identificador de harness no es v\xE1lido.",
    badVersion: "La versi\xF3n de la instalaci\xF3n no es v\xE1lida.",
    verifyMissing: (path) => `Falta el fichero ${path}.`,
    verifyVersion: (path) => `La versi\xF3n gestionada de ${path} no coincide.`,
    verifyHook: "El hook sint\xE9tico no lleg\xF3 al runtime.",
    verifyNone: "No hay una instalaci\xF3n de Factory en este directorio personal.",
    removedNone: "No hay una instalaci\xF3n que restaurar.",
    claudeCliUnconfirmed: "Los ficheros de Claude Code quedan en el directorio personal. El marketplace (`claude plugin`) no est\xE1 confirmado por el spike: si el comando no existe, la copia en ~/.factory/link/claude-code sigue siendo la instalaci\xF3n.",
    cursorReload: "Hay que recargar Cursor para que cargue los hooks y el MCP.",
    templateMissing: (relativePath, root) => `Falta la plantilla de Factory Link: ${relativePath} (busqu\xE9 en ${root}). Vuelve a ejecutar \`factory install\` o define FACTORY_LINK_TEMPLATES.`
  }
};

// packages/harness-kit/src/hook/args.ts
var ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,64}$/;
function flagValue(argv, index) {
  const value = argv[index];
  if (value === void 0 || value.startsWith("-")) return void 0;
  return value;
}
function parseArgs(argv) {
  if (argv.length === 1 && argv[0] === "probe") return { kind: "probe" };
  if (argv[0] === "watch") {
    let harness2;
    let session;
    for (let i = 1; i < argv.length; i += 1) {
      const flag = argv[i];
      if (flag === "--harness") {
        const value = flagValue(argv, i + 1);
        if (value === void 0) return { kind: "usage" };
        harness2 = value;
        i += 1;
        continue;
      }
      if (flag === "--session") {
        const value = flagValue(argv, i + 1);
        if (value === void 0) return { kind: "usage" };
        session = value;
        i += 1;
        continue;
      }
      return { kind: "usage" };
    }
    if (harness2 === void 0 || !ID.test(harness2)) return { kind: "usage" };
    if (session !== void 0 && !ID.test(session)) return { kind: "usage" };
    if (session !== void 0) return { kind: "watch", harness: harness2, session };
    return { kind: "watch", harness: harness2 };
  }
  const harness = argv[0];
  const event = argv[1];
  if (argv.length === 2 && harness !== void 0 && event !== void 0 && ID.test(harness) && ID.test(event)) {
    return { kind: "forward", harness, event };
  }
  return { kind: "usage" };
}

// packages/harness-kit/src/hook/forward.ts
import { resolve as resolve2 } from "node:path";

// packages/harness-kit/src/record.ts
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// packages/harness-kit/src/hook/constants.ts
var HOOK_PATH = "/api/v1/link/hook";
var HELLO_PATH = "/api/v1/hello";
var INBOX_STREAM_PATH = "/api/v1/link/inbox/stream";
var STDIN_MAX_BYTES = 1024 * 1024;
var SPOOL_MAX_BYTES = 20 * 1024 * 1024;
var OBSERVE_TIMEOUT_MS = 1500;
var GOVERNED_TIMEOUT_MS = 2500;
var HELLO_WAIT_MS = 1500;
var PROBE_TIMEOUT_MS = 2e3;
var LOG_MAX_BYTES = 1024 * 1024;
var GOVERNED = /* @__PURE__ */ new Set([
  "SessionStart",
  "sessionStart",
  "UserPromptSubmit",
  "beforeSubmitPrompt",
  "PreToolUse",
  "preToolUse",
  "beforeShellExecution",
  "beforeMCPExecution",
  "Stop",
  "stop"
]);
function isGovernedEvent(event) {
  return GOVERNED.has(event);
}
function isSessionStart(event) {
  return event === "SessionStart" || event === "sessionStart";
}
function hookTimeoutMs(event) {
  return isGovernedEvent(event) ? GOVERNED_TIMEOUT_MS : OBSERVE_TIMEOUT_MS;
}
function spoolBudget(env) {
  const raw = env.FACTORY_SPOOL_MAX_BYTES;
  if (raw !== void 0 && /^[1-9]\d*$/.test(raw)) return Number(raw);
  return SPOOL_MAX_BYTES;
}

// packages/harness-kit/src/hook/home.ts
import { homedir } from "node:os";
import { join } from "node:path";
function userHome(env = process.env) {
  const home = env.HOME;
  if (home !== void 0 && home.length > 0) return home;
  return homedir();
}
function factoryHome(env = process.env) {
  const configured = env.FACTORY_HOME;
  if (configured !== void 0 && configured.length > 0) return configured;
  return join(userHome(env), ".factory");
}

// packages/harness-kit/src/hook/log.ts
import { appendFileSync, chmodSync, mkdirSync, renameSync, statSync } from "node:fs";
import { join as join2 } from "node:path";
function hookLogPath(factoryHomeDir) {
  return join2(factoryHomeDir, "logs", "hook.log");
}
function logHook(factoryHomeDir, message) {
  try {
    const dir = join2(factoryHomeDir, "logs");
    mkdirSync(dir, { recursive: true, mode: 448 });
    chmodSync(dir, 448);
    const path = hookLogPath(factoryHomeDir);
    try {
      if (statSync(path).size > LOG_MAX_BYTES) renameSync(path, `${path}.1`);
    } catch {
    }
    const line = JSON.stringify({ at: (/* @__PURE__ */ new Date()).toISOString(), message });
    appendFileSync(path, `${line}
`, { encoding: "utf8", mode: 384 });
    chmodSync(path, 384);
  } catch {
  }
}

// packages/harness-kit/src/version.ts
var HOOK_VERSION = "0.3.0";

// packages/harness-kit/src/hook/http.ts
import { request } from "node:http";
function httpRequest(options) {
  return new Promise((resolve3, reject) => {
    const body = options.body;
    const headers = {
      Authorization: `Bearer ${options.token}`,
      Accept: "application/json"
    };
    if (body !== void 0) {
      headers["Content-Type"] = "application/json";
      headers["Content-Length"] = Buffer.byteLength(body);
    }
    const req = request(
      {
        host: "127.0.0.1",
        port: options.port,
        method: options.method,
        path: options.path,
        ...options.timeoutMs > 0 ? { timeout: options.timeoutMs } : {},
        headers
      },
      (res) => {
        const chunks = [];
        res.on("data", (chunk) => {
          chunks.push(chunk);
        });
        res.on("end", () => {
          resolve3({ status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString("utf8") });
        });
      }
    );
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.on("error", reject);
    if (body !== void 0) req.write(body);
    req.end();
  });
}
function openStream(options) {
  return new Promise((resolve3, reject) => {
    const req = request(
      {
        host: "127.0.0.1",
        port: options.port,
        method: "GET",
        path: options.path,
        ...options.timeoutMs > 0 ? { timeout: options.timeoutMs } : {},
        headers: {
          Authorization: `Bearer ${options.token}`,
          Accept: "text/event-stream"
        }
      },
      (res) => {
        resolve3(res);
      }
    );
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.on("error", reject);
    req.end();
  });
}

// packages/harness-kit/src/hook/runtime-files.ts
import { readFileSync } from "node:fs";
import { join as join3 } from "node:path";
function parseRuntime(value) {
  if (typeof value !== "object" || value === null) return void 0;
  const record = value;
  const port = record.port;
  const pid = record.pid;
  if (typeof port !== "number" || !Number.isInteger(port) || port <= 0 || port > 65535 || typeof pid !== "number" || !Number.isInteger(pid) || pid <= 0) {
    return void 0;
  }
  return { port, pid };
}
function pidAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}
function readRuntime(factoryHomeDir) {
  let meta;
  try {
    meta = parseRuntime(
      JSON.parse(readFileSync(join3(factoryHomeDir, "runtime", "runtime.json"), "utf8"))
    );
  } catch {
    return void 0;
  }
  if (!meta || !pidAlive(meta.pid)) return void 0;
  let token = "";
  try {
    token = readFileSync(join3(factoryHomeDir, "runtime", "token"), "utf8").trim();
  } catch {
    return void 0;
  }
  if (token.length === 0) return void 0;
  return { home: factoryHomeDir, port: meta.port, pid: meta.pid, token };
}

// packages/harness-kit/src/hook/probe.ts
function buildHookBody(input) {
  return JSON.stringify({
    v: 1,
    harness: input.harness,
    event: input.event,
    hookVersion: input.hookVersion ?? HOOK_VERSION,
    receivedAt: input.now.toISOString(),
    ppid: input.ppid,
    payload: input.payload
  });
}
async function postHook(factoryHomeDir, body, timeoutMs) {
  const runtime = readRuntime(factoryHomeDir);
  if (!runtime) return void 0;
  try {
    return await httpRequest({
      port: runtime.port,
      method: "POST",
      path: HOOK_PATH,
      token: runtime.token,
      body,
      timeoutMs
    });
  } catch {
    return void 0;
  }
}
async function waitForHello(factoryHomeDir, timeoutMs = HELLO_WAIT_MS) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const runtime = readRuntime(factoryHomeDir);
    if (runtime) {
      try {
        const result = await httpRequest({
          port: runtime.port,
          method: "GET",
          path: HELLO_PATH,
          token: runtime.token,
          timeoutMs: Math.max(50, Math.min(200, deadline - Date.now()))
        });
        if (result.status >= 200 && result.status < 300) return true;
      } catch {
      }
    }
    await new Promise((resolve3) => {
      setTimeout(resolve3, 40);
    });
  }
  return false;
}
async function probeRuntime(factoryHomeDir, input) {
  const body = buildHookBody({
    harness: "probe",
    event: "probe",
    payload: { cwd: input.cwd, synthetic: true },
    now: input.now,
    ppid: input.ppid
  });
  const result = await postHook(factoryHomeDir, body, PROBE_TIMEOUT_MS);
  return result !== void 0 && result.status >= 200 && result.status < 300;
}

// packages/harness-kit/src/hook/spool.ts
import {
  appendFileSync as appendFileSync2,
  chmodSync as chmodSync2,
  mkdirSync as mkdirSync2,
  readdirSync,
  readFileSync as readFileSync2,
  rmSync,
  statSync as statSync2
} from "node:fs";
import { join as join4 } from "node:path";
function safeHarness(harness) {
  return harness.replace(/[^A-Za-z0-9._-]/g, "_");
}
function spoolFilePath(input) {
  const y = input.now.getUTCFullYear().toString();
  const m = String(input.now.getUTCMonth() + 1).padStart(2, "0");
  const d = String(input.now.getUTCDate()).padStart(2, "0");
  return join4(
    input.factoryHome,
    "link",
    "spool",
    safeHarness(input.harness),
    `${y}${m}${d}-${input.pid}.jsonl`
  );
}
function listJsonl(dir) {
  let entries;
  try {
    entries = readdirSync(dir, { withFileTypes: true });
  } catch {
    return [];
  }
  const files = [];
  for (const entry of entries) {
    const path = join4(dir, entry.name);
    if (entry.isDirectory()) files.push(...listJsonl(path));
    else if (entry.isFile() && entry.name.endsWith(".jsonl")) files.push(path);
  }
  return files;
}
function lineCount(path) {
  try {
    return readFileSync2(path, "utf8").split("\n").filter((line) => line.length > 0).length;
  } catch {
    return 0;
  }
}
function writeLine(path, line) {
  mkdirSync2(join4(path, ".."), { recursive: true, mode: 448 });
  chmodSync2(join4(path, ".."), 448);
  appendFileSync2(path, `${line}
`, { encoding: "utf8", mode: 384 });
  chmodSync2(path, 384);
}
function appendSpool(input) {
  const dir = join4(input.factoryHome, "link", "spool");
  const max = spoolBudget(input.env);
  const incoming = Buffer.byteLength(input.line) + 1;
  if (incoming > max) {
    logHook(input.factoryHome, strings.hook.spoolDropped(1));
    return;
  }
  const files = listJsonl(dir).map((path2) => {
    const stat = statSync2(path2);
    return { path: path2, mtimeMs: stat.mtimeMs, size: stat.size, lines: lineCount(path2) };
  }).sort((a, b) => a.mtimeMs - b.mtimeMs || a.path.localeCompare(b.path));
  let total = files.reduce((sum, file) => sum + file.size, 0);
  let dropped = 0;
  while (total + incoming > max && files.length > 0) {
    const oldest = files.shift();
    if (!oldest) break;
    rmSync(oldest.path, { force: true });
    total -= oldest.size;
    dropped += oldest.lines;
  }
  const path = spoolFilePath(input);
  writeLine(path, input.line);
  if (dropped > 0) {
    const note = JSON.stringify({
      v: 1,
      kind: "spool-dropped",
      dropped,
      at: input.now.toISOString()
    });
    writeLine(path, note);
    logHook(input.factoryHome, strings.hook.spoolDropped(dropped));
  }
}

// packages/harness-kit/src/hook/start-runtime.ts
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { join as join5 } from "node:path";
function launch(command, args, factoryHomeDir, extraEnv) {
  try {
    const child = spawn(command, args, {
      detached: true,
      stdio: "ignore",
      env: { ...process.env, ...extraEnv, FACTORY_HOME: factoryHomeDir }
    });
    child.on("error", () => void 0);
    child.unref();
    return true;
  } catch {
    return false;
  }
}
function startRuntimeDetached(factoryHomeDir, env) {
  if (env.FACTORY_NO_AUTOSTART === "1") return "skipped";
  const override = env.FACTORY_RUNTIME_START;
  if (override !== void 0 && override.length > 0) {
    if (!existsSync(override)) return "missing";
    return launch(override, ["--home", factoryHomeDir], factoryHomeDir, env) ? "spawned" : "missing";
  }
  const bundled = join5(factoryHomeDir, "app", "current", "factory.mjs");
  if (existsSync(bundled)) {
    const ok = launch(
      process.execPath,
      [bundled, "__runtime", "--home", factoryHomeDir],
      factoryHomeDir,
      {
        FACTORY_ENTRY_PREFIX: "__runtime"
      }
    );
    return ok ? "spawned" : "missing";
  }
  const shim = join5(factoryHomeDir, "bin", "factory");
  if (existsSync(shim)) {
    const ok = launch(shim, ["__runtime", "--home", factoryHomeDir], factoryHomeDir, {
      FACTORY_ENTRY_PREFIX: "__runtime"
    });
    return ok ? "spawned" : "missing";
  }
  return "missing";
}

// packages/harness-kit/src/hook/workspace.ts
import { existsSync as existsSync2 } from "node:fs";
import { dirname, join as join6, parse, resolve } from "node:path";
function findWorkspaceFile(start, home) {
  let dir = resolve(start);
  const stop = resolve(home);
  const fsRoot = parse(dir).root;
  for (; ; ) {
    const candidate = join6(dir, ".factory", "workspace.yaml");
    if (existsSync2(candidate)) return candidate;
    if (dir === stop || dir === fsRoot || existsSync2(join6(dir, ".git"))) return void 0;
    const parent = dirname(dir);
    if (parent === dir) return void 0;
    dir = parent;
  }
}
function cwdFromPayload(payload) {
  if (!isRecord(payload)) return void 0;
  if (typeof payload.cwd === "string" && payload.cwd.length > 0) return payload.cwd;
  const roots = payload.workspace_roots ?? payload.workspaceRoots;
  if (Array.isArray(roots)) {
    const first = roots[0];
    if (typeof first === "string" && first.length > 0) return first;
  }
  return void 0;
}

// packages/harness-kit/src/hook/stdin.ts
var TOOL_FIELDS = ["tool_response", "tool_output"];
async function readStdin(stream, maxBytes = STDIN_MAX_BYTES) {
  const chunks = [];
  let size = 0;
  let truncated = false;
  for await (const piece of stream) {
    const buf = typeof piece === "string" ? Buffer.from(piece) : Buffer.from(piece);
    if (truncated) continue;
    if (size + buf.length > maxBytes) {
      const keep = maxBytes - size;
      if (keep > 0) chunks.push(buf.subarray(0, keep));
      size = maxBytes;
      truncated = true;
      continue;
    }
    chunks.push(buf);
    size += buf.length;
  }
  return { text: Buffer.concat(chunks).toString("utf8"), truncated };
}
function recoverCwd(text) {
  const match = /"cwd"\s*:\s*"((?:\\.|[^"\\])*)"/.exec(text);
  const raw = match?.[1];
  if (raw === void 0) return void 0;
  try {
    const parsed = JSON.parse(`"${raw}"`);
    return typeof parsed === "string" && parsed.length > 0 ? parsed : void 0;
  } catch {
    return void 0;
  }
}
function markTruncated(payload) {
  if (!isRecord(payload)) return { truncated: true };
  const next = { ...payload, truncated: true };
  for (const key of TOOL_FIELDS) {
    const value = next[key];
    if (typeof value === "string" && value.length > 1024) next[key] = value.slice(0, 1024);
  }
  return next;
}
function preparePayload(text, truncated) {
  const trimmed = text.trim();
  if (trimmed.length === 0) return { payload: {}, cwd: void 0, invalid: false };
  try {
    const parsed = JSON.parse(trimmed);
    const payload = truncated ? markTruncated(parsed) : parsed;
    return { payload, cwd: cwdFromPayload(payload), invalid: false };
  } catch {
    const cwd = recoverCwd(text);
    if (!truncated) return { payload: {}, cwd, invalid: true };
    const payload = cwd !== void 0 ? { cwd, truncated: true } : { truncated: true };
    return { payload, cwd, invalid: false };
  }
}

// packages/harness-kit/src/hook/forward.ts
function readResponse(text) {
  let value;
  try {
    value = JSON.parse(text);
  } catch {
    return void 0;
  }
  if (!isRecord(value) || value.v !== 1) return void 0;
  if (value.exitCode !== 0 && value.exitCode !== 2) return void 0;
  const stdout = typeof value.stdout === "string" ? value.stdout : void 0;
  const stderr = typeof value.stderr === "string" ? value.stderr : void 0;
  return {
    exitCode: value.exitCode,
    ...stdout !== void 0 ? { stdout } : {},
    ...stderr !== void 0 ? { stderr } : {}
  };
}
function startNote(attempt) {
  if (attempt === "spawned") return strings.hook.startSpawned;
  if (attempt === "skipped") return strings.hook.startSkipped;
  return strings.hook.startMissing;
}
async function forwardHook(io, harness, event, stdinText, truncated) {
  const prepared = preparePayload(stdinText, truncated);
  const home = userHome(io.env);
  const root = factoryHome(io.env);
  const cwd = resolve2(io.cwd, prepared.cwd ?? io.cwd);
  if (findWorkspaceFile(cwd, home) === void 0) return 0;
  if (prepared.invalid) {
    logHook(root, strings.hook.payloadInvalid);
    return 0;
  }
  if (truncated) logHook(root, strings.hook.stdinTruncated);
  const body = buildHookBody({
    harness,
    event,
    payload: prepared.payload,
    now: io.now(),
    ppid: io.ppid
  });
  const result = await postHook(root, body, hookTimeoutMs(event));
  if (result !== void 0 && result.status >= 200 && result.status < 300) {
    const response = readResponse(result.body);
    if (response) {
      if (response.stdout !== void 0) io.stdout(response.stdout);
      if (response.stderr !== void 0) io.stderr(response.stderr);
      return response.exitCode;
    }
    logHook(root, strings.hook.responseInvalid);
  }
  appendSpool({ factoryHome: root, harness, line: body, now: io.now(), pid: io.pid, env: io.env });
  const attempt = startRuntimeDetached(root, io.env);
  logHook(root, `${strings.hook.runtimeDown} ${startNote(attempt)} (${harness} ${event})`);
  if (attempt === "spawned" && isSessionStart(event)) await waitForHello(root, HELLO_WAIT_MS);
  return 0;
}

// packages/harness-kit/src/hook/watch.ts
function formatNotice(data) {
  try {
    const parsed = JSON.parse(data);
    if (isRecord(parsed) && typeof parsed.text === "string") {
      return parsed.text.endsWith("\n") ? parsed.text : `${parsed.text}
`;
    }
    if (isRecord(parsed) && typeof parsed.message === "string") {
      return parsed.message.endsWith("\n") ? parsed.message : `${parsed.message}
`;
    }
  } catch {
  }
  return data.endsWith("\n") ? data : `${data}
`;
}
function readSse(res, onData) {
  return new Promise((resolve3, reject) => {
    let buffer = "";
    res.setEncoding("utf8");
    res.on("data", (chunk) => {
      buffer += chunk;
      const parts = buffer.split("\n\n");
      buffer = parts.pop() ?? "";
      for (const part of parts) {
        for (const line of part.split("\n")) {
          if (line.startsWith("data:")) onData(line.slice(5).trim());
        }
      }
    });
    res.on("end", () => {
      resolve3();
    });
    res.on("error", reject);
  });
}
async function watchInbox(io, harness, session) {
  const home = userHome(io.env);
  const root = factoryHome(io.env);
  if (findWorkspaceFile(io.cwd, home) === void 0) return 0;
  const runtime = readRuntime(root);
  if (!runtime) {
    logHook(root, strings.hook.runtimeDown);
    return 0;
  }
  const query = new URLSearchParams({ harness });
  if (session !== void 0) query.set("session", session);
  try {
    const res = await openStream({
      port: runtime.port,
      path: `${INBOX_STREAM_PATH}?${query.toString()}`,
      token: runtime.token,
      timeoutMs: 0
    });
    const status = res.statusCode ?? 0;
    if (status < 200 || status >= 300) {
      res.resume();
      logHook(root, strings.hook.runtimeDown);
      return 0;
    }
    await readSse(res, (data) => {
      io.stdout(formatNotice(data));
    });
    return 0;
  } catch {
    logHook(root, strings.hook.runtimeDown);
    return 0;
  }
}

// packages/harness-kit/src/hook/main.ts
function processIo() {
  return {
    argv: process.argv.slice(2),
    env: process.env,
    cwd: process.cwd(),
    stdin: process.stdin,
    stdout: (text) => {
      process.stdout.write(text);
    },
    stderr: (text) => {
      process.stderr.write(text);
    },
    now: () => /* @__PURE__ */ new Date(),
    pid: process.pid,
    ppid: process.ppid
  };
}
async function runHook(io = processIo()) {
  const parsed = parseArgs(io.argv);
  const tty = "isTTY" in io.stdin && io.stdin.isTTY === true;
  const input = tty ? { text: "", truncated: false } : await readStdin(io.stdin);
  if (parsed.kind === "usage") {
    io.stderr(`${strings.hook.usage}
`);
    return 2;
  }
  if (parsed.kind === "probe") {
    const ok = await probeRuntime(factoryHome(io.env), {
      cwd: io.cwd,
      now: io.now(),
      ppid: io.ppid
    });
    if (ok) return 0;
    logHook(factoryHome(io.env), strings.hook.probeFailed);
    io.stderr(`${strings.hook.probeFailed}
`);
    return 2;
  }
  if (parsed.kind === "watch") {
    const session = "session" in parsed ? parsed.session : void 0;
    return watchInbox(io, parsed.harness, session);
  }
  if (io.env["FACTORY_HEADLESS_RUN"] === "1") return 0;
  return forwardHook(io, parsed.harness, parsed.event, input.text, input.truncated);
}
function invokedDirectly() {
  const entry = process.argv[1];
  if (entry === void 0) return false;
  try {
    const entryUrl = pathToFileURL(realpathSync(entry)).href;
    const selfUrl = pathToFileURL(realpathSync(fileURLToPath(import.meta.url))).href;
    return entryUrl === selfUrl;
  } catch {
    return false;
  }
}
if (invokedDirectly()) {
  runHook().then((code) => {
    process.exit(code);
  }).catch(() => {
    try {
      logHook(factoryHome(), strings.hook.failed);
    } catch {
    }
    process.exit(0);
  });
}
export {
  runHook
};
