# write-acceptance

Escribe `.factory/acceptance/<INT>/acceptance.yaml` y las pruebas de aceptación en rutas protegidas (`*.acceptance.test.*`). Un criterio por bloque. Prefiere comportamiento observable. Si un criterio no es ejecutable, márcalo `manual` con un motivo en `note`. No escribas código de producto.

## Formato exacto (se valida al cerrar la etapa)

```yaml
intent: INT-7
criteria:
  - id: AC-1
    text: "truncate('Hola mundo', 4) devuelve 'Hola…'"
    checks:
      - kind: test
        command: checks.test
        selector: src/truncate.acceptance.test.js
        files: [src/truncate.acceptance.test.js]
  - id: AC-2
    text: 'Un texto más corto que el límite no cambia'
    checks:
      - kind: manual
        note: 'Revisión visual en la maqueta'
```

Reglas que comprueba el validador:

- `intent`: el id de la intención (`INT-<n>`).
- `criteria[].id`: **`AC-1`, `AC-2`, …** en el orden de los criterios de la intención. Ningún otro formato (`CA-1`, `AC1`, `criterio-1` no valen).
- `criteria[].text`: el criterio, en una línea, entre comillas.
- `criteria[].checks`: lista con al menos un check. Cada check tiene `kind` (`test`, `property`, `e2e` o `manual`) y, si no es manual, `command` con un check del workspace: `checks.<nombre>` tal como aparece en `.factory/workspace.yaml` (por ejemplo `checks.test`). Nunca un comando de shell.
- Claves opcionales del check: `selector` (letras, números y `./:@#-`), `files` (lista de rutas) y `note`. No añadas otras claves (`source`, `trace`…): rompen la validación.
- Pon entre comillas cualquier texto con `:`, `#` o paréntesis.

Antes de terminar, relee el archivo y comprueba que cumple estas reglas. Si la etapa falla con «acceptance.yaml no es válido (…)», corrige exactamente lo que dice el motivo.
