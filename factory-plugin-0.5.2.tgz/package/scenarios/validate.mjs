#!/usr/bin/env node
/**
 * Validates fixtures/scenarios/{mockups,int-104}: scenario.yaml, timeline.yaml,
 * named checkpoints, and fake-harness scripts. Materializes facts with a fixed
 * seed and checks they parse as contracts Fact values.
 */
import { spawnSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const repo = join(root, '../..');

function ensureBuilt(filter, distFile) {
  if (existsSync(distFile)) return;
  const result = spawnSync('pnpm', ['--filter', filter, 'build'], {
    cwd: repo,
    stdio: 'inherit',
  });
  if (result.status !== 0) {
    console.error(`error: failed to build ${filter}`);
    process.exit(1);
  }
}

ensureBuilt('@factory/contracts', join(repo, 'packages/contracts/dist/index.js'));
ensureBuilt('@factory/harness-fake', join(repo, 'packages/harness-fake/dist/script.js'));

const { Fact } = await import(pathToFileURL(join(repo, 'packages/contracts/dist/index.js')).href);
const { FakeScript } = await import(
  pathToFileURL(join(repo, 'packages/harness-fake/dist/script.js')).href
);

const require = createRequire(join(repo, 'packages/contracts/package.json'));
const { parse } = require('yaml');

const errors = [];
const SCENARIOS = ['mockups', 'int-104'];

const SECRET =
  /(?:AKIA[0-9A-Z]{16}|sk-(?:ant|live|proj)-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)/;

function fail(message) {
  errors.push(message);
}

function readYaml(path) {
  return parse(readFileSync(path, 'utf8'));
}

function walkFiles(dir, out = []) {
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, name.name);
    if (name.isDirectory()) walkFiles(path, out);
    else out.push(path);
  }
  return out;
}

function assertScenarioShape(id, scenario) {
  if (!scenario || typeof scenario !== 'object') {
    fail(`${id}/scenario.yaml must be an object`);
    return;
  }
  if (scenario.id !== id) fail(`${id}/scenario.yaml id must be "${id}"`);
  if (typeof scenario.seed !== 'number' || !Number.isInteger(scenario.seed)) {
    fail(`${id}/scenario.yaml seed must be an integer`);
  }
  if (!scenario.clock?.start || Number.isNaN(Date.parse(scenario.clock.start))) {
    fail(`${id}/scenario.yaml clock.start must be an ISO timestamp`);
  }
  if (!scenario.personas || typeof scenario.personas !== 'object') {
    fail(`${id}/scenario.yaml personas is required`);
  }
  if (!Array.isArray(scenario.workspaces) || scenario.workspaces.length === 0) {
    fail(`${id}/scenario.yaml workspaces must be a non-empty array`);
  }
  for (const [i, ws] of (scenario.workspaces ?? []).entries()) {
    const src = ws?.source;
    if (!src?.app || !['cursor', 'vscode', 'cli'].includes(src.app)) {
      fail(`${id}/scenario.yaml workspaces[${i}].source.app invalid`);
    }
  }
  if (!Array.isArray(scenario.checkpoints) || scenario.checkpoints.length === 0) {
    fail(`${id}/scenario.yaml checkpoints must be a non-empty array`);
  }
  const seen = new Set();
  for (const cp of scenario.checkpoints ?? []) {
    if (!cp?.id || typeof cp.offsetMs !== 'number') {
      fail(`${id}/scenario.yaml checkpoint needs id and offsetMs`);
      continue;
    }
    if (seen.has(cp.id)) fail(`${id}/scenario.yaml duplicate checkpoint ${cp.id}`);
    seen.add(cp.id);
  }
  if (!scenario.sessions || typeof scenario.sessions !== 'object') {
    fail(`${id}/scenario.yaml sessions is required`);
  }
}

/**
 * Build Fact[] from timeline rows. Rows omit seq/at; those are assigned here.
 * Same seed + same timeline → identical facts (including order).
 */
/**
 * Build Fact[] from timeline rows. Rows omit seq/at; those are assigned here.
 * Order is offsetMs, then idempotencyKey. The seed is recorded on the scenario
 * so simulate (MVP-RT-03) can replay the same cut; materialization itself is
 * fully determined by timeline + clock.start.
 */
export function materializeFacts(scenario, timeline, seed = scenario.seed) {
  void seed; // recorded on scenario for simulate (MVP-RT-03); order is timeline-determined
  const start = Date.parse(scenario.clock.start);
  const rows = Array.isArray(timeline) ? [...timeline] : [];
  rows.sort((a, b) => {
    const d = (a.offsetMs ?? 0) - (b.offsetMs ?? 0);
    if (d !== 0) return d;
    const ka = String(a.idempotencyKey ?? '');
    const kb = String(b.idempotencyKey ?? '');
    return ka < kb ? -1 : ka > kb ? 1 : 0;
  });
  return rows.map((row, index) => {
    const { offsetMs, ...rest } = row;
    const at = new Date(start + Number(offsetMs)).toISOString();
    return { ...rest, seq: index + 1, at };
  });
}

function validateUsageHonesty(fact, label) {
  for (const key of ['tokens', 'cost']) {
    const usage = fact[key];
    if (!usage || typeof usage !== 'object') continue;
    if (usage.kind === 'unavailable' && Object.hasOwn(usage, 'value')) {
      fail(`${label}: unavailable ${key} must not carry a value (never 0)`);
    }
    if (usage.kind === 'unavailable' && (!usage.why || usage.why.length === 0)) {
      fail(`${label}: unavailable ${key} needs why`);
    }
  }
}

function validateScenario(id) {
  const dir = join(root, id);
  const scenarioPath = join(dir, 'scenario.yaml');
  const timelinePath = join(dir, 'timeline.yaml');
  const scenario = readYaml(scenarioPath);
  const timeline = readYaml(timelinePath);

  assertScenarioShape(id, scenario);

  if (!Array.isArray(timeline)) {
    fail(`${id}/timeline.yaml must be an array`);
    return;
  }

  for (const [i, row] of timeline.entries()) {
    if (typeof row?.offsetMs !== 'number' || row.offsetMs < 0) {
      fail(`${id}/timeline.yaml[${i}] offsetMs must be a non-negative number`);
    }
    if (!row?.idempotencyKey || typeof row.idempotencyKey !== 'string') {
      fail(`${id}/timeline.yaml[${i}] idempotencyKey is required`);
    }
  }

  const keys = timeline.map((r) => r.idempotencyKey);
  if (new Set(keys).size !== keys.length) {
    fail(`${id}/timeline.yaml idempotencyKey values must be unique`);
  }

  const factsA = materializeFacts(scenario, timeline, scenario.seed);
  const factsB = materializeFacts(scenario, timeline, scenario.seed);
  if (JSON.stringify(factsA) !== JSON.stringify(factsB)) {
    fail(`${id}: same seed must yield identical facts`);
  }

  let cursorUnavailable = false;
  for (const [i, fact] of factsA.entries()) {
    const parsed = Fact.safeParse(fact);
    if (!parsed.success) {
      const detail = parsed.error.issues
        .map((issue) => `${issue.path.join('.') || '(root)'}: ${issue.message}`)
        .join('; ');
      fail(`${id}/timeline.yaml fact[${i}] (${fact.type}): ${detail}`);
      continue;
    }
    validateUsageHonesty(parsed.data, `${id} fact[${i}]`);
    if (
      parsed.data.type === 'usage.reported' &&
      (parsed.data.tokens?.kind === 'unavailable' || parsed.data.cost?.kind === 'unavailable')
    ) {
      cursorUnavailable = true;
    }
  }

  if (id === 'mockups') {
    const ids = new Set((scenario.checkpoints ?? []).map((c) => c.id));
    if (!ids.has('inicio')) fail('mockups must declare checkpoint inicio');
    if (!ids.has('mockup-2')) fail('mockups must declare checkpoint mockup-2');
    if (!cursorUnavailable) {
      fail('mockups must include usage.reported with unavailable (Cursor · never 0)');
    }
    const marked = factsA.filter((f) => f.type === 'simulation.marked');
    for (const need of ['inicio', 'mockup-2']) {
      if (!marked.some((f) => f.checkpoint === need && f.scenario === 'mockups')) {
        fail(`mockups timeline missing simulation.marked checkpoint=${need}`);
      }
    }
  }

  if (id === 'int-104') {
    const proposed = factsA.filter((f) => f.type === 'intent.proposed').map((f) => f.intentId);
    const created = factsA.filter((f) => f.type === 'intent.created').map((f) => f.intentId);
    const active = [
      'INT-104',
      'INT-109',
      'INT-111',
      'INT-112',
      'INT-113',
      'INT-116',
      'INT-110',
      'INT-114',
      'INT-117',
    ];
    const delivered = ['INT-101', 'INT-102', 'INT-106'];
    for (const intentId of [...active, ...delivered]) {
      if (!proposed.includes(intentId)) fail(`int-104 missing intent.proposed ${intentId}`);
      if (!created.includes(intentId)) fail(`int-104 missing intent.created ${intentId}`);
    }
    const decisions = factsA
      .filter((f) => f.type === 'decision.requested')
      .map((f) => f.decisionId);
    for (const need of ['perm', 'g112', 'g114']) {
      if (!decisions.includes(need)) fail(`int-104 missing decision.requested ${need}`);
    }
    if (!cursorUnavailable) {
      fail('int-104 must include usage.reported with unavailable (Cursor · never 0)');
    }
  }

  for (const [sessionId, session] of Object.entries(scenario.sessions ?? {})) {
    const rel = session?.script;
    if (!rel || typeof rel !== 'string') {
      fail(`${id} session ${sessionId} needs script path`);
      continue;
    }
    const scriptPath = join(dir, rel);
    try {
      statSync(scriptPath);
    } catch {
      fail(`${id} session ${sessionId} script missing: ${rel}`);
      continue;
    }
    const raw = readYaml(scriptPath);
    const parsed = FakeScript.safeParse(raw ?? {});
    if (!parsed.success) {
      const detail = parsed.error.issues
        .map((issue) => `${issue.path.join('.') || '(root)'}: ${issue.message}`)
        .join('; ');
      fail(`${id}/${rel}: ${detail}`);
      continue;
    }
    for (const [si, step] of parsed.data.steps.entries()) {
      if (step.type !== 'usage') continue;
      for (const key of ['tokens', 'cost']) {
        const usage = step[key];
        if (usage?.kind === 'unavailable' && Object.hasOwn(usage, 'value')) {
          fail(`${id}/${rel} step[${si}]: unavailable ${key} must not carry a value`);
        }
      }
    }
  }
}

for (const id of SCENARIOS) {
  validateScenario(id);
}

for (const file of walkFiles(root)) {
  if (file.endsWith('validate.mjs')) continue;
  const text = readFileSync(file, 'utf8');
  if (SECRET.test(text)) {
    fail(`secret-like pattern in ${relative(repo, file)}`);
  }
}

if (errors.length > 0) {
  for (const message of errors) console.error(`error: ${message}`);
  process.exit(1);
}

console.log('fixtures/scenarios: ok (mockups, int-104)');
