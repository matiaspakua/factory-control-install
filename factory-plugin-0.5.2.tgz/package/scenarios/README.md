# Simulation scenarios

Deterministic fixtures for offline development and `factory simulate` (MVP-RT-03).

| Scenario            | Purpose                                                                                                                                   |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| `mockups/`          | Mockups 1 and 2 (Bugfix, Classic, PoC). Checkpoint `inicio` = Resumen; `mockup-2` advances Classic to Generar código en espera.           |
| `int-104/`          | Prototipo 4 starting state: 9 active intents, 3 delivered, decisions `perm` / `g112` / `g114`. Deployment is an F4 alert, not a Decision. |
| `f2m-verified/`     | Low-risk express through green gates and a full evidence matrix (live runtime, not simulate).                                             |
| `f2m-tamper/`       | Fake `write_file` edits an acceptance test; `tamper-scan` fails with a line.                                                              |
| `f2m-unconfigured/` | Missing `checks.test`; the gate blocks and a waiver lands in the evidence pack.                                                           |
| `f2m-escalate/`     | Express touches `src/auth/`; the plan adds a human security review.                                                                       |
| `f2m-why/`          | Two intents touch `src/auth/login.ts`; `factory why` lists both decisions.                                                                |
| `f2m-plugin-off/`   | `verify/acceptance` off: no `acceptance-design`, no protected-rule block.                                                                 |

`f2m-*` are harness overlays for `tests/e2e` (a real runtime and the fake harness). They are not `factory simulate` timelines. A `scripts/<stage>.yaml` file is copied to `.factory/harness-scripts/` before the run.

## Layout

Each scenario directory:

- `scenario.yaml` — id, seed, clock start, personas, workspaces (with origin), named checkpoints (`offsetMs`), sessions → fake-harness scripts
- `timeline.yaml` — facts from `@factory/contracts` `Fact`, each with `offsetMs` from `clock.start` (no `seq` / `at`; assigned on materialize)
- `scripts/*.yaml` — `@factory/harness-fake` scripts per session

## Verify

```bash
node fixtures/scenarios/validate.mjs
```

Requires built `packages/contracts` and `packages/harness-fake`.

Cursor usage is always `unavailable` with a `why` — never a numeric 0 (RN-41).
