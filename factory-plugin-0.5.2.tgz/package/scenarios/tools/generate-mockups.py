#!/usr/bin/env python3
"""Regenerates fixtures/scenarios/mockups/timeline.yaml.

The timeline is written so the engine reaches the states of mockups 1 and 2 by itself: every
finished stage has its declared evidence before `stage.completed` (RN-45), held and running stages
have a session, and nothing is shown as measured that the harness did not report.

    python3 fixtures/scenarios/tools/generate-mockups.py
"""
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[3]
CORE = ROOT / "factory-core" / "process"
OUT = ROOT / "fixtures" / "scenarios" / "mockups" / "timeline.yaml"
START_MS = 0  # offsets are relative to clock.start (09:00:00Z)
MIN = 60_000


def stage_info(stage_id):
    data = yaml.safe_load((CORE / "stages" / f"{stage_id}.yaml").read_text())
    return data.get("scope", "intent"), data.get("evidence") or ["artifact"]


def hm(h, m, s=0):
    """Offset in ms of hh:mm:ss after the 09:00:00 start."""
    return ((h - 9) * 60 + m) * MIN + s * 1000


facts = []
n = 0


def add(offset, type_, actor, **fields):
    global n
    n += 1
    facts.append({"offsetMs": offset, "type": type_, "actor": actor,
                  "idempotencyKey": f"mockups:{n:04d}:{type_}", **fields})


RT = {"kind": "runtime"}
LAURA = {"kind": "person", "id": "laura"}
AGENT = lambda i: {"kind": "agent", "id": i}


def finish_stage(inst, stage_id, unit, start, minutes, session):
    """ready → started → session → evidence → completed, the way a real run leaves the log."""
    scope, evidence = stage_info(stage_id)
    run_id = f"{inst}:{stage_id}" + (f":{unit}" if unit else "")
    unit_f = {"unitId": unit} if unit else {}
    add(start, "stage.ready", RT, instanceId=inst, stageId=stage_id)
    add(start + 1000, "stage.started", RT, instanceId=inst, stageId=stage_id, **unit_f)
    add(start + 2000, "session.started", RT, sessionId=session, runId=run_id)
    end = start + minutes * MIN
    for ev in evidence:
        if ev in ("human-approval", "checks.test"):
            continue
        add(end - 2000, "evidence.declared", AGENT("claude-code"), evidenceId=ev,
            summary=f"Evidencia {ev} declarada", instanceId=inst, stageId=stage_id, **unit_f)
    add(end - 1000, "session.ended", RT, sessionId=session)
    add(end, "stage.completed", RT, instanceId=inst, stageId=stage_id, **unit_f)


def start_stage(inst, stage_id, unit, start, session):
    run_id = f"{inst}:{stage_id}" + (f":{unit}" if unit else "")
    unit_f = {"unitId": unit} if unit else {}
    add(start, "stage.ready", RT, instanceId=inst, stageId=stage_id)
    add(start + 1000, "stage.started", RT, instanceId=inst, stageId=stage_id, **unit_f)
    add(start + 2000, "session.started", RT, sessionId=session, runId=run_id)


# ── Workspaces and factory ──────────────────────────────────────────────────────────────────
for ident, app, window in (("cursor-w1", "cursor", "1"), ("cursor-w2", "cursor", "2"), ("cli-w1", "cli", None)):
    source = {"app": app, **({"window": window} if window else {})}
    add(0, "workspace.registered", RT, workspaceId=ident, path="examples/sandbox-product", source=source)
add(1000, "factory.started", LAURA, harnessId="cursor")

# ── Bugfix · Reintentos de pago (Construir y probar en marcha) ───────────────────────────────
add(hm(9, 1), "intent.proposed", AGENT("foreman"), intentId="INT-BUG", title="Reintentos de pago",
    why="El adaptador de pagos no reintenta fallos transitorios",
    criteria=["Los reintentos se aplican sin secretos en el código",
              "Hay evidencia declarada de la prueba local"])
add(hm(9, 2), "intent.created", LAURA, intentId="INT-BUG", workflowId="bugfix", units=["api"])
t = hm(9, 3)
for i, sid in enumerate(["intent-capture", "reverse-engineering", "code-generation"]):
    finish_stage("INT-BUG", sid, "api" if stage_info(sid)[0] == "unit" else None, t, 8, f"ses-bug-{i}")
    t += 9 * MIN
start_stage("INT-BUG", "build-and-test", "api", hm(10, 20), "ses-bugfix")
add(hm(10, 30), "progress.reported", RT, sessionId="ses-bugfix", done=3, total=5)
add(hm(10, 31), "harness.event", RT, sessionId="ses-bugfix",
    event={"type": "tool_call", "id": "t1", "name": "Bash", "input": {"command": "pnpm test"}})
add(hm(10, 41, 30), "usage.reported", RT, sessionId="ses-bugfix",
    tokens={"kind": "unavailable", "why": "Cursor no informa los tokens"},
    cost={"kind": "unavailable", "why": "Cursor no informa el coste"})

# ── Classic · Alta de clientes (Generar código, unidad 2 en espera) ──────────────────────────
UNITS = ["unit-1", "unit-2", "unit-3", "unit-4"]
add(hm(9, 5), "intent.proposed", AGENT("foreman"), intentId="INT-CLASSIC", title="Alta de clientes",
    why="Dar de alta personas y, si aplica, empresas",
    criteria=["Se pueden dar de alta personas", "Las empresas son opcionales", "Hay una prueba por unidad"])
add(hm(9, 6), "intent.created", LAURA, intentId="INT-CLASSIC", workflowId="classic", units=UNITS)
classic = ["intent-capture", "reverse-engineering", "practices-discovery", "requirements-analysis", "user-stories",
           "refined-mockups", "domain-design", "units-generation", "contract-design", "delivery-planning"]
t = hm(9, 7)
for i, sid in enumerate(classic):
    finish_stage("INT-CLASSIC", sid, None, t, 5, f"ses-cl-{i}")
    t += 6 * MIN
# Independent design work after delivery-planning (t is about 10:10).
for i, sid in enumerate(["functional-design", "nfr-requirements", "infrastructure-design"]):
    finish_stage("INT-CLASSIC", sid, None, t, 7, f"ses-cl-d{i}")
    t += 2 * MIN
finish_stage("INT-CLASSIC", "nfr-design", None, t + 8 * MIN, 5, "ses-cl-nfr")
# Code generation per unit: 1 and 3 run, 2 is held for the security review, 4 waits for a slot.
cg = hm(10, 15)
start_stage("INT-CLASSIC", "code-generation", "unit-2", cg, "ses-classic")
add(cg + 3 * MIN, "harness.event", RT, sessionId="ses-classic",
    event={"type": "message", "role": "assistant", "text": "Voy a tocar el adaptador de pagos."})
add(cg + 3 * MIN + 1000, "agent.said", RT, sessionId="ses-classic", text="Voy a tocar el adaptador de pagos.")
add(hm(10, 24), "terminal.message", LAURA, workflowId="INT-CLASSIC", message={
    "voice": "person", "author": "Persona local", "at": "2026-10-21T10:24:00.000Z", "timeLabel": "10:24",
    "text": "Pon Generar código en espera hasta que seguridad apruebe el adaptador de pagos."})
add(hm(10, 24, 5), "stage.held", LAURA, instanceId="INT-CLASSIC", stageId="code-generation",
    reason="Esperando la aprobación de seguridad del adaptador de pagos")
add(hm(10, 24, 6), "session.ended", RT, sessionId="ses-classic")
add(hm(10, 24, 10), "memory.appended", LAURA, instanceId="INT-CLASSIC",
    text="Generar código queda en espera hasta que seguridad apruebe el adaptador de pagos.")
add(hm(10, 24, 20), "terminal.message", RT, workflowId="INT-CLASSIC", message={
    "voice": "runtime", "author": "runtime", "at": "2026-10-21T10:24:20.000Z", "timeLabel": "10:24",
    "text": "Etapa en espera. Memoria actualizada. Sigue en paralelo: Generar código · unit-1 y Generar código · unit-3."})
add(hm(10, 25), "decision.requested", RT, decisionId="revision-seguridad", kind="gate",
    title="Revisión de seguridad del adaptador de pagos",
    reason="El diff toca **/payment*/**: hace falta la revisión del Equipo de seguridad",
    intentId="INT-CLASSIC", stageId="code-generation")
start_stage("INT-CLASSIC", "code-generation", "unit-1", hm(10, 26), "ses-cl-u1")
add(hm(10, 40), "progress.reported", RT, sessionId="ses-cl-u1", done=3, total=5)
add(hm(10, 40, 5), "harness.event", RT, sessionId="ses-cl-u1",
    event={"type": "file_change", "path": "src/customers/create.ts", "change": "created"})
start_stage("INT-CLASSIC", "code-generation", "unit-3", hm(10, 27), "ses-cl-u3")
add(hm(10, 41, 50), "progress.reported", RT, sessionId="ses-cl-u3", done=7, total=20)
add(hm(10, 41, 55), "harness.event", RT, sessionId="ses-cl-u3",
    event={"type": "file_change", "path": "src/customers/validate.ts", "change": "modified"})
add(hm(10, 41, 56), "terminal.message", RT, workflowId="INT-CLASSIC", message={
    "voice": "harness", "author": "Cursor Agent", "at": "2026-10-21T10:41:56.000Z", "timeLabel": "10:41",
    "text": "La unidad 2 espera la revisión de seguridad. Sigo con las unidades 1 y 3."})
add(hm(10, 41, 57), "usage.reported", RT, sessionId="ses-cl-u1",
    tokens={"kind": "unavailable", "why": "Cursor no informa los tokens"},
    cost={"kind": "unavailable", "why": "Cursor no informa el coste"})

# ── PoC · Asistente de voz (en pausa en Viabilidad) ──────────────────────────────────────────
add(hm(9, 40), "intent.proposed", AGENT("foreman"), intentId="INT-POC", title="Asistente de voz",
    why="Comprobar si un asistente de voz es viable para la atención al cliente",
    criteria=["Hay una conclusión de viabilidad por escrito"])
add(hm(9, 41), "intent.created", LAURA, intentId="INT-POC", workflowId="poc", units=["api"])
finish_stage("INT-POC", "intent-capture", None, hm(9, 42), 8, "ses-poc-0")
start_stage("INT-POC", "feasibility", None, hm(10, 5), "ses-poc")
add(hm(10, 12), "session.ended", RT, sessionId="ses-poc")
add(hm(10, 12, 1), "stage.held", LAURA, instanceId="INT-POC", stageId="feasibility",
    reason="Esperando presupuesto")
add(hm(10, 12, 2), "workflow.paused", LAURA, instanceId="INT-POC", reason="Pausado por Laura")

facts.sort(key=lambda f: (f["offsetMs"], f["idempotencyKey"]))
header = ("# Timeline for mockups. offsetMs from clock.start; seq/at are assigned when it is materialized.\n"
          "# GENERATED by fixtures/scenarios/tools/generate-mockups.py: edit the script, not this file.\n")
class NoAliases(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


OUT.write_text(header + yaml.dump(facts, Dumper=NoAliases, sort_keys=False, allow_unicode=True, width=120))
print(f"{len(facts)} facts → {OUT.relative_to(ROOT)}")
