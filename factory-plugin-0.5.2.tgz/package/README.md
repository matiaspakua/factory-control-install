# @aguvoda/factory-plugin

Instala Factory Control (CLI `factory`, runtime local, dashboard y extensión para VS Code y Cursor).
El archivo `hook.mjs` es la entrada `factory-hook`.

```bash
npx @aguvoda/factory-plugin@latest install
```

Requiere Node.js 22 o superior.
