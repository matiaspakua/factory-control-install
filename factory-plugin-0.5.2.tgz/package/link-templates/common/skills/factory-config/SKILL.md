---
name: factory-config
description: Borrador para ajustar Factory Control. SKL-01 completa esta skill. Úsala solo cuando la persona pida cambiar el proceso, un gate o una política.
---

# factory-config

Esta skill es un borrador. Cuando la persona pida configuración, llama a `factory_status` y explícale que el ajuste fino todavía no está en el chat.
No cambies políticas, gates ni el CORE por tu cuenta. Ofrece abrir el panel con `factory_open_dashboard`.
