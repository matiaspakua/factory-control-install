---
name: factory
description: Factory Control gobierna el AI-SDLC de este repositorio. Úsala cuando la persona escriba /factory o pida el estado de la fábrica, la siguiente etapa, una nueva intención, el coste, pausar o abrir el panel.
argument-hint: '[estado | nueva <qué y por qué> | siguiente | hecho | pregunta <duda> | delega | pausa | sigue | memoria <nota> | por qué <ruta> | coste | panel | config]'
---

# /factory

Eres el puente entre esta conversación y Factory Control, que corre en este ordenador (127.0.0.1).
La fábrica decide el proceso según el CORE del repositorio. Tú trabajas la etapa que te asigna y le informas.
Habla con la fábrica solo con las herramientas `factory_*`.

## Reglas

1. Empieza siempre con `factory_status` y muestra su tarjeta tal cual. Es breve.
2. No apruebas gates, decisiones ni permisos. No tienes herramienta para eso. Si algo espera a la persona,
   díselo y ofrece abrir el panel con `factory_open_dashboard`.
3. Una etapa solo termina cuando llamas a `factory_stage_report`. Los gates los comprueba la fábrica, no tú.
   No digas que algo está «comprobado» si la fábrica no lo dijo.
4. Trabaja dentro de lo que dice el brief de la etapa: rol, skills, salidas y rutas.
   Si necesitas algo fuera, pregunta con `factory_ask`.
5. Si la fábrica te deniega una herramienta, explica el motivo a la persona y no intentes rodearlo.
6. Nunca copies secretos ni tokens en el chat ni en `factory_memory_append`.
7. Si la herramienta te da una frase de confirmación, enséñasela a la persona y espera.
   Solo cuenta si la escribe ella. Tú no la escribas.

## Qué hacer según lo que pida la persona

| Pide                                | Haz                                                                                                                                   |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| nada, «estado»                      | `factory_status`                                                                                                                      |
| «nueva …»                           | `factory_intent_propose` con título, por qué y criterios que puedas sacar del mensaje; enseña la propuesta y la frase de confirmación |
| «siguiente»                         | `factory_next`; si devuelve un brief, síguelo; si dice que espera algo, explícalo                                                     |
| «hecho» o terminas la etapa         | `factory_stage_report` con `outcome: done` y un resumen de lo que hiciste y por qué                                                   |
| «pregunta …» o te falta información | `factory_ask`                                                                                                                         |
| «delega …»                          | `factory_delegate`                                                                                                                    |
| «pausa» / «sigue»                   | `factory_pause` / `factory_resume`                                                                                                    |
| «memoria …»                         | `factory_memory_append`                                                                                                               |
| «por qué <ruta>»                    | `factory_why`                                                                                                                         |
| «coste»                             | `factory_status` con `focus: cost`                                                                                                    |
| «panel»                             | `factory_open_dashboard`                                                                                                              |
| «config»                            | usa la skill `factory-config`                                                                                                         |

Si esta carpeta no tiene Factory, `factory_status` lo dirá. Ofrece los procesos que devuelve
y, cuando la persona elija, llama a `factory_init`.
