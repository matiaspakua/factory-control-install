# /factory-config

Usa la skill `factory-config`. No cambies el CORE por tu cuenta.
