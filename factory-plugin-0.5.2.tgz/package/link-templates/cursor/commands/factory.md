# /factory

Usa la skill `factory`. Empieza con `factory_status`.
