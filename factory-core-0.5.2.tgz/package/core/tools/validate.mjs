#!/usr/bin/env node
import { readFileSync, readdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  AgentFrontmatter,
  FactoryFile,
  ModelsFile,
  PhasesFile,
  PluginManifest,
  PluginsFile,
  PoliciesFile,
  StageFile,
  WorkflowFile,
} from '../../packages/contracts/dist/index.js';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const repo = join(root, '..');
const require = createRequire(join(repo, 'packages/contracts/package.json'));
const { parse } = require('yaml');

const errors = [];

function fail(message) {
  errors.push(message);
}

function readYaml(rel) {
  return parse(readFileSync(join(root, rel), 'utf8'));
}

function check(rel, schema, value) {
  const result = schema.safeParse(value);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.') || '(root)'}: ${issue.message}`)
      .join('; ');
    fail(`${rel} ${detail}`);
  }
}

const SECRET =
  /(?:AKIA[0-9A-Z]{16}|sk-(?:ant|live|proj)-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)/;

function walk(dir, out = []) {
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, name.name);
    if (name.isDirectory()) walk(path, out);
    else out.push(path);
  }
  return out;
}

check('factory.yaml', FactoryFile, readYaml('factory.yaml'));
check('policies.yaml', PoliciesFile, readYaml('policies.yaml'));
check('models.yaml', ModelsFile, readYaml('models.yaml'));
check('plugins.yaml', PluginsFile, readYaml('plugins.yaml'));
check('process/phases.yaml', PhasesFile, readYaml('process/phases.yaml'));

const flags = JSON.parse(readFileSync(join(root, 'flags.json'), 'utf8'));
if (!flags.flags || typeof flags.flags !== 'object') {
  fail('flags.json must be a flagd document with a flags object');
}
for (const [key, flag] of Object.entries(flags.flags)) {
  if (!key.startsWith('plugin.')) fail(`flags.json key ${key} must start with plugin.`);
  if (!flag || typeof flag !== 'object') fail(`flags.json ${key} must be an object`);
}

const policies = readYaml('policies.yaml');
const allowed = policies.harnesses?.allowed ?? [];
for (const id of ['claude-code', 'cursor', 'fake']) {
  if (!allowed.includes(id)) fail(`policies.yaml missing harness ${id}`);
}
const obligationIds = new Set((policies.obligations ?? []).map((item) => item.id));
if (!obligationIds.has('human-approval') || !obligationIds.has('security-review')) {
  fail('policies.yaml must obligate human-approval and security-review');
}

const phases = readYaml('process/phases.yaml').phases.map((phase) => phase.name);
const expectedPhases = ['Inicialización', 'Ideación', 'Concepción', 'Construcción', 'Operación'];
if (JSON.stringify(phases) !== JSON.stringify(expectedPhases)) {
  fail(`phases.yaml names ${phases.join(', ')}`);
}

const stageIds = new Set();
for (const name of readdirSync(join(root, 'process/stages'))) {
  if (!name.endsWith('.yaml')) continue;
  const rel = `process/stages/${name}`;
  const stage = readYaml(rel);
  check(rel, StageFile, stage);
  stageIds.add(stage.id);
}
const expectedStageCount = 49; // 34 AI-DLC + acceptance-design + mutation-sample + OpenSpec (5) + Spec Kit (8)
if (stageIds.size !== expectedStageCount || !stageIds.has('delivery-merge')) {
  fail(`expected ${expectedStageCount} stages including delivery-merge, found ${stageIds.size}`);
}
for (const id of [
  'opsx-explore',
  'opsx-propose',
  'opsx-apply',
  'opsx-verify',
  'opsx-archive',
  'speckit-specify',
  'speckit-clarify',
  'speckit-plan',
  'speckit-checklist',
  'speckit-tasks',
  'speckit-analyze',
  'speckit-implement',
  'speckit-converge',
]) {
  if (!stageIds.has(id)) fail(`missing process stage ${id}`);
}

const classicAgents = [
  ['intent-capture', 'product', []],
  ['reverse-engineering', 'architect', ['intent-capture']],
  ['practices-discovery', 'quality', ['reverse-engineering']],
  ['requirements-analysis', 'product', ['practices-discovery']],
  ['user-stories', 'product', ['requirements-analysis']],
  ['refined-mockups', 'ux', ['user-stories']],
  ['domain-design', 'architect', ['refined-mockups']],
  ['units-generation', 'developer', ['domain-design']],
  ['contract-design', 'architect', ['units-generation']],
  ['delivery-planning', 'product', ['contract-design']],
  ['functional-design', 'architect', ['delivery-planning']],
  ['nfr-requirements', 'quality', ['delivery-planning']],
  ['nfr-design', 'architect', ['nfr-requirements']],
  ['infrastructure-design', 'devsecops', ['delivery-planning']],
  ['acceptance-design', 'quality', ['functional-design', 'nfr-design', 'infrastructure-design']],
  ['code-generation', 'developer', ['acceptance-design']],
  ['build-and-test', 'pipeline-deploy', ['code-generation']],
  ['ci-pipeline', 'devsecops', ['build-and-test']],
  // The factory never merges alone: classic ends in the human gate too.
  ['delivery-merge', 'quality', ['ci-pipeline']],
];

function stageEntries(workflow) {
  return workflow.stages.map((entry) => {
    if (typeof entry === 'string') return { id: entry, override: {} };
    const keys = Object.keys(entry);
    if (keys.length !== 1) fail('workflow stage entry must have one id');
    const id = keys[0];
    return { id, override: entry[id] ?? {} };
  });
}

for (const name of readdirSync(join(root, 'process/workflows'))) {
  if (!name.endsWith('.yaml')) continue;
  const rel = `process/workflows/${name}`;
  const workflow = readYaml(rel);
  check(rel, WorkflowFile, workflow);
  for (const { id } of stageEntries(workflow)) {
    if (!stageIds.has(id)) fail(`${rel} references unknown stage ${id}`);
  }
  if (workflow.id === 'classic') {
    if (workflow.title !== 'Classic · Feature Delivery') fail('classic title mismatch');
    const entries = stageEntries(workflow);
    if (entries.length !== classicAgents.length)
      fail(`classic must have ${classicAgents.length} stages`);
    classicAgents.forEach(([id, agentId, needs], index) => {
      const entry = entries[index];
      if (!entry || entry.id !== id) fail(`classic stage ${index} expected ${id}`);
      if (entry?.override.agent !== agentId) fail(`classic ${id} agent expected ${agentId}`);
      const got = entry?.override.needs ?? [];
      if (JSON.stringify(got) !== JSON.stringify(needs)) {
        fail(`classic ${id} needs ${JSON.stringify(got)} expected ${JSON.stringify(needs)}`);
      }
    });
  }
}

const gateFiles = {
  'human-approval': { type: 'human', check: 'human-approval', maturity: 'implemented' },
  // Its path trigger (policies.yaml) is not enforced yet: documented, not active.
  'security-review': { type: 'human', check: 'security-review', maturity: 'defined' },
  'local-tests': { type: 'quality', check: 'checks.test', maturity: 'implemented' },
  'local-lint': { type: 'quality', check: 'checks.lint', maturity: 'implemented' },
  coverage: { type: 'quality', check: 'coverage', maturity: 'defined' },
  a11y: { type: 'quality', check: 'a11y', maturity: 'defined' },
};

for (const [name, expect] of Object.entries(gateFiles)) {
  const rel = `gates/${name}.yaml`;
  const raw = readYaml(rel);
  if (!Number.isInteger(raw.max_loops) || raw.max_loops < 1) fail(`${rel} needs max_loops`);
  if (!raw.gate?.on_fail?.return_to) fail(`${rel} needs on_fail.return_to`);
  if (raw.maturity !== expect.maturity) fail(`${rel} maturity`);
  if (raw.gate?.type !== expect.type) fail(`${rel} type`);
  const checks = (raw.gate?.evidence ?? []).map((item) => item.check);
  if (!checks.includes(expect.check)) fail(`${rel} evidence ${expect.check}`);
  if (name === 'security-review' && !String(raw.summary).includes('Equipo de seguridad')) {
    fail(`${rel} must name Equipo de seguridad`);
  }
  const manifest = { ...raw };
  delete manifest.max_loops;
  check(rel, PluginManifest, manifest);
}

const skillIds = new Set(
  readdirSync(join(root, 'skills'), { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => entry.name),
);
for (const id of [
  'write-spec',
  'react-ui',
  'write-tests',
  'security-review',
  'aidlc-aws',
  'openspec',
  'speckit',
]) {
  if (!skillIds.has(id)) fail(`missing skill ${id}`);
}

for (const name of ['aidlc-aws', 'openspec', 'speckit']) {
  const rel = `process/workflows/${name}.yaml`;
  if (!readdirSync(join(root, 'process/workflows')).includes(`${name}.yaml`)) {
    fail(`missing primary process workflow ${rel}`);
  }
  const pluginRel = `plugins/${name}/plugin.yaml`;
  check(pluginRel, PluginManifest, readYaml(pluginRel));
}

const requiredTools = ['request_input', 'declare_evidence', 'append_memory'];
for (const name of readdirSync(join(root, 'agents'))) {
  if (!name.endsWith('.md')) continue;
  const rel = `agents/${name}`;
  const text = readFileSync(join(root, rel), 'utf8');
  const match = text.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
  if (!match) {
    fail(`${rel} missing frontmatter`);
    continue;
  }
  const data = parse(match[1]);
  check(rel, AgentFrontmatter, data);
  for (const skill of data.skills ?? []) {
    if (!skillIds.has(skill)) fail(`${rel} unknown skill ${skill}`);
  }
  for (const tool of requiredTools) {
    if (!match[2].includes(tool)) fail(`${rel} instructions must mention ${tool}`);
  }
}

for (const rule of ['no-secrets.md', 'run-tests.md', 'spanish-artifacts.md']) {
  const body = readFileSync(join(root, 'rules/factory', rule), 'utf8');
  if (body.trim().length < 40) fail(`rules/factory/${rule} is empty`);
}

const readme = readFileSync(join(root, 'README.md'), 'utf8');
for (const phrase of ['Cómo se lee', 'Cómo se cambia', 'Qué es obligatorio']) {
  if (!readme.includes(phrase)) fail(`README missing ${phrase}`);
}

for (const file of walk(root)) {
  const text = readFileSync(file, 'utf8');
  if (SECRET.test(text)) fail(`possible secret in ${file}`);
}

if (errors.length > 0) {
  for (const error of errors) console.error(error);
  process.exit(1);
}
console.log('factory-core ok');
