# Ledger

Notas de intención y reglas aprendidas. Los archivos de `rules/learned/` los crea el plugin cuando una persona confirma una candidata. Esta nota no vive en `rules/` para no entrar en todos los prompts.
