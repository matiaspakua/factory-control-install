# Spec Kit · Spec-Driven Development

Regla del flujo **Spec Kit** (specify → clarify → plan → checklist → tasks →
analyze → implement → converge).

## Qué implica

- La especificación y el plan van **antes** de implementar.
- Factory orquesta; no inventes atajos que salten etapas con landmark `human`
  o `gate` en el mapa AI-SDLC.
- `delivery-merge` sigue siendo el gate humano enforceable del CORE.

## Cómo actuar

1. Specify/clarify: deja la spec clara y las preguntas resueltas.
2. Plan/tasks: desglosa trabajo verificable; no implementes aún.
3. Implement/converge: cumple el plan; deja evidencia para el merge.
