# write-acceptance

Escribe `.factory/acceptance/<INT>/acceptance.yaml` y las pruebas en rutas protegidas.
Un criterio por bloque. Preferir comportamiento observable. Si no es ejecutable, marca `manual` y un motivo.
No escribas código de producto.
