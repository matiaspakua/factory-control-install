# Pruebas de aceptación

Las pruebas de aceptación son de solo lectura. Si crees que una está mal, pide input con `request_input`.
