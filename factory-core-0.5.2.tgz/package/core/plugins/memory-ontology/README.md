# memory-ontology

Vocabulario `fc:` (`fc.ttl`) y formas de calidad (`fc-shapes.ttl`) de la memoria de Factory Control.

- Exporta con `factory memory export --format turtle|jsonld [--intent INT-4]`.
- Valida con cualquier motor SHACL, o con el plugin opcional `memory/open-ontologies`.
- Las reglas necesitan un motor SHACL con soporte de `sh:sparql` (Open Ontologies lo tiene).

El vocabulario se alinea con PROV-O (`prov:`), Dublin Core (`dcterms:`) y SKOS (`skos:`). No hay
dependencia de un proveedor: la fuente de verdad es el diario de la memoria, no la ontología.
