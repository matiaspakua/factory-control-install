# OpenSpec · propuesta antes de código

Regla del bucle **OpenSpec** (explore → propose → apply → verify → archive).

## Qué implica

- No escribas código de producto hasta que `opsx-propose` deje proposal, specs,
  design y tasks revisables bajo `openspec/`.
- Factory orquesta las etapas; el harness solo ejecuta la etapa actual.
- El landmark `human` en propose/verify/archive marca paradas de revisión en el
  mapa AI-SDLC.

## Cómo actuar

1. En explore: acota el problema y las alternativas.
2. En propose: deja artefactos completos; no apruebes en nombre de la persona.
3. En apply: implementa solo lo aprobado; en verify/archive cierra el cambio.
