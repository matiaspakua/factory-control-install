# AIDLC · aprobación humana

Regla de metodología **AWS AI-DLC** (Classic Feature Delivery).

## Qué implica

- Tras completar el trabajo de una etapa, el proceso espera **revisión humana**
  antes de tratarla como lista para la siguiente.
- Factory Control orquesta el avance; **no** uses el CLI `aidlc` ni `/aidlc`
  como conductor.
- El gate enforceable del CORE es `factory/human-approval` en `delivery-merge`.
  Las demás paradas HITL del pack son puntos del mapa AI-SDLC (landmarks):
  configúralas como gates cuando el workspace quiera forzarlas.

## Cómo actuar

1. Deja el artefacto de la etapa bajo `.factory/intents/<INT>/`.
2. Resume riesgos y preguntas abiertas; no apruebes en nombre de la persona.
3. Si la etapa tiene landmark `human`, el mapa lo muestra como parada obligatoria
   a tener en cuenta mientras el proceso está en curso.
