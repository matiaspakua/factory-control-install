# Factory CORE · Draclab

Proceso por defecto del MVP (id `draclab`, versión 3). Es texto: la factory lo lee y no lo ejecuta sola.

## Cómo se lee

- `factory.yaml` identifica la factory y los valores por defecto (`claude-code`, `maxParallel: 2`).
- `policies.yaml` dice qué harnesses valen, qué gates son obligatorios y qué no puede hacer un agente (escribir solo en la unidad, sin `git push`, red solo con permiso).
- `models.yaml` resuelve los alias `razonamiento`, `codigo` y `rapido` en cada harness.
- `plugins.yaml` carga solo `factory/local` (instalado ≠ activado).
- `system-plugins.yaml` es el catálogo LEGO del sistema (vistas, temas, MCP, OpenTelemetry, …). JSON Schema: `system-plugins.schema.json`.
- `flags.json` activa cada pieza con forma [flagd](https://flagd.dev) / OpenFeature (`plugin.<id>`). Lo obligatorio no se apaga.
- `process/phases.yaml` son las cinco fases de AI-DLC, con nombre en español.
- `process/stages/` es la biblioteca: 33 etapas de AI-DLC más `delivery-merge`.
- `process/workflows/` elige un subconjunto. **AWS AI-DLC (family `aidlc`):** 11 perfiles
  (`classic`, `express`, `feature`, `bugfix`, `refactor`, `infra`, `security-patch`,
  `poc`, `mvp`, `enterprise`, `workshop`) sobre las 5 fases y 33 etapas; en Config se
  revisan, habilitan/deshabilitan y personalizan etapas. `aidlc-aws` es alias de empaquetado
  de Classic. **Otros:** `openspec`, `speckit`, `feature-ui`, `linea-clasica`. Factory
  orquesta; no uses el CLI `aidlc` como conductor.
- `plugins/` declara los manifiestos LEGO de esos tres procesos; `plugins.yaml` los referencia por `path`.
- `plugins/<id>/pack.yaml` aporta catálogo **aditivo** (skills, rules, hooks, commands, landmarks del mapa AI-SDLC). Nunca sobrescribe ni borra ids ya presentes en el CORE; `plugins/<id>/skills` y `plugins/<id>/rules` solo se suman si el id es nuevo.
- `gates/` define los gates. `coverage` y `a11y` están definidos; los demás, implementados como declaración.
- `agents/` son las instrucciones que reciben Claude Code y Cursor. `skills/` (`aidlc-aws`, `openspec`, `speckit`, …) y `rules/factory/` son el oficio común. Los landmarks del pack marcan paradas HITL/externas en el mapa; el gate humano enforceable sigue en `delivery-merge`.

## Cómo se cambia

1. Edita el YAML o el markdown en este directorio.
2. Valida: `node factory-core/tools/validate.mjs`.
3. No cambies los identificadores de una etapa que ya usa un workflow sin actualizar ese workflow.
4. Un gate nuevo necesita `on_fail.return_to` y `max_loops`.

## Qué es obligatorio

- Gate humano en `delivery-merge`. La factory no fusiona sola.
- Revisión de seguridad, con responsable el rol Equipo de seguridad, cuando el diff toca `**/payment*/**`, `**/auth/**` o dependencias.
- Permisos máximos: escribir solo en las rutas de la unidad, sin `git push`, red solo con permiso.
- Sin secretos ni datos personales en este árbol.
- Artefactos de etapa en español.

En Classic, Diseño de infraestructura, Diseño funcional y Requisitos no funcionales comparten la dependencia `delivery-planning` y pueden avanzar en paralelo. Generar código espera a las tres ramas.
