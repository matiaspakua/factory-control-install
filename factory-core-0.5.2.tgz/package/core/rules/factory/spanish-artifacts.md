# Artefactos en español

Los artefactos de etapa (`.factory/intents/<INT>/<etapa>.md`), las notas de memoria y los textos que ve la persona se escriben en español. Los identificadores del código siguen en inglés.
