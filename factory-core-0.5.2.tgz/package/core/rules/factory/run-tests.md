# Pruebas antes de terminar

Antes de cerrar una etapa que toca código, ejecuta las pruebas de la unidad y declara el resultado. Si no se pudieron ejecutar, dilo y no marques la evidencia como comprobada. Una etapa no está hecha sin su evidencia.
