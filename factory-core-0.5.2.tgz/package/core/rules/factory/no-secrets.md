# Sin secretos en el código

No escribas tokens, claves, contraseñas ni datos personales en código, pruebas, fixtures, eventos, artefactos ni en el navegador. Un ejemplo usa un valor falso y obvio, nunca una credencial real. Si una herramienta devuelve un secreto, no lo copies a la memoria ni al artefacto.
