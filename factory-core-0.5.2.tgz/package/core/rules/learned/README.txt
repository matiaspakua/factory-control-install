Las reglas aprendidas se crean aquí al confirmar una candidata. Cada archivo .md lleva activation.paths.
