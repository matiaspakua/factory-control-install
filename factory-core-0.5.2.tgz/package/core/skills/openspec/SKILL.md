# openspec

Metodología **OpenSpec** ([openspec.dev](https://openspec.dev/)).

## Orquestación · Factory

Factory avanza las etapas `opsx-*`. Escribe los artefactos **en las rutas nativas de OpenSpec** (`openspec/…`): así la CLI `openspec` y sus comandos `/opsx:*` los ven. Factory los cataloga en su memoria sin moverlos.

## Bucle

1. **Explorar** — investiga y aclara; no escribas código ni carpeta de cambio.
2. **Proponer** — crea `openspec/changes/<cambio>/` con:
   - `proposal.md` (por qué / qué)
   - `specs/` (deltas ADDED/MODIFIED/REMOVED)
   - `design.md` (cómo, si hace falta)
   - `tasks.md` (checklist)
3. **Aplicar** — implementa marcando checkboxes en `tasks.md`.
4. **Verificar** — la implementación cumple proposal + specs + tasks.
5. **Archivar** — fusiona deltas en `openspec/specs/` y mueve el cambio a `openspec/changes/archive/`.

## Reglas

- Los artefactos del cambio van en `openspec/changes/<cambio>/` (español). En `.factory/intents/<INT>/opsx-*.md` solo dejas preguntas abiertas y el resumen de la etapa.
- Antes de crear una especificación, busca si ya existe una en `openspec/specs/` y actualízala en el cambio (deltas) en vez de duplicarla.
- No apruebes el gate humano de entrega ni hagas merge a main.
