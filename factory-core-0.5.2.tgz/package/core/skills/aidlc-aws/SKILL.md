# aidlc-aws

Metodología **AWS AI-DLC** (alineada a [awslabs/aidlc-workflows v2.11.1](https://github.com/awslabs/aidlc-workflows/tree/v2.11.1)).

## Orquestación · Factory es el conductor

- Factory Control avanza etapas, gates, sesiones de harness y evidencia.
- **No** invoques el CLI `aidlc`, ni `/aidlc`, ni `$aidlc` como orquestador.
- El harness (Claude Code, Cursor, …) solo ejecuta el trabajo de **esta etapa**.
- Artefactos de etapa en español bajo `.factory/intents/<INT>/`.

## Cómo trabajar cada etapa

1. Lee la intención, la memoria del workflow y los outputs de etapas `needs`.
2. Produce solo lo que pide la etapa actual (inputs → outputs del stage YAML).
3. Deja preguntas abiertas juntas; no apruebes gates humanos ni fusiones.
4. Respeta políticas: escritura solo en la unidad, sin `git push`, red con permiso.
5. En Classic, Diseño funcional / NFR / infraestructura pueden avanzar en paralelo tras `delivery-planning`; Generar código espera a las tres.

## Referencia

Perfil Classic Feature Delivery de AI-DLC: Inception + Construction hasta Build and Test, con aprobación humana en `delivery-merge`.
