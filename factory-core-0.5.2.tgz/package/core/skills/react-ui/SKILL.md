# react-ui

Construye o describe interfaz con el sistema visual del prototipo 4.

1. Usa los tokens y componentes existentes. No inventes colores sueltos.
2. Cubre vacío, error, carga y dato no disponible. «No disponible» no es 0.
3. Comprueba escritorio y móvil, y el contraste del texto.
4. Si solo diseñas, entrega el flujo en el artefacto de la etapa. Si escribes código, limítate a las rutas de la unidad y acompáñalo de una prueba.
