# write-tests

Añade pruebas que fallen si el criterio deja de cumplirse.

1. Ata cada prueba a un criterio del spec.
2. No uses la red. Loopback sí.
3. No fijes secretos, tokens ni datos personales en fixtures.
4. Ejecuta el check de la unidad antes de dar la etapa por cerrada y declara el resultado.
