# write-spec

Escribe un spec comprobable.

1. Parte de la intención: qué, por qué y quién lo sufre.
2. Separa lo que entra de lo que no entra.
3. Redacta cada criterio para que Calidad pueda ejecutarlo o señalar que no se puede.
4. Deja las preguntas abiertas juntas, al final, y no las conviertas en decisiones.
5. Guarda el texto en la ruta que pide la etapa (`outputs`): la nativa del framework si la hay (`openspec/changes/…`, `specs/<feature>/…`) o, si no, `.factory/intents/<INT>/<etapa>.md`. Siempre en español.
6. Si ya existe un artefacto del mismo tipo y ámbito (consulta la memoria del proyecto), actualízalo en lugar de crear otro.
