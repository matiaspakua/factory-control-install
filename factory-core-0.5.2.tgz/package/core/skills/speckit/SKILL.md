# speckit

Metodología **Spec Kit** · Spec-Driven Development ([github/spec-kit](https://github.com/github/spec-kit)).

## Orquestación · Factory

Factory avanza las etapas `speckit-*`. Escribe los artefactos **en las rutas nativas de Spec Kit** (`specs/<feature>/…` y `.specify/memory/constitution.md`) para que sus comandos `/speckit.*` los vean. Factory los cataloga en su memoria sin moverlos.

## Bucle SDD

1. **Especificar** — `specs/<feature>/spec.md` (qué / por qué / viajes de usuario).
2. **Clarificar** — resuelve ambigüedad en la spec.
3. **Planificar** — `plan.md` (stack, arquitectura, restricciones).
4. **Checklist** — calidad de requisitos.
5. **Tareas** — `tasks.md` en unidades pequeñas y comprobables.
6. **Analizar** — coherencia spec ↔ plan ↔ tasks.
7. **Implementar** — ejecuta tareas; marca progreso en `tasks.md`.
8. **Converger** — evalúa código vs artefactos; si faltan piezas, añádelas y reporta hasta «Converged».

## Reglas

- Una etapa = un resultado revisable. No saltes a código en specify/plan.
- Los artefactos de la funcionalidad van en `specs/<feature>/` (español). En `.factory/intents/<INT>/speckit-*.md` solo dejas preguntas abiertas y el resumen de la etapa.
- Respeta la constitución (`.specify/memory/constitution.md`) y no la reescribas sin que lo pida una persona.
- No apruebes el gate humano ni fusiones a main.
