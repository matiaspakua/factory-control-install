# security-review

Revisa el diff cuando toca pagos, autenticación o dependencias.

1. Mira autorización, validación de entradas y secretos en código, fixtures y logs.
2. Señala la ruta y el motivo. No copies el secreto.
3. Si el hallazgo bloquea, pide una decisión al Equipo de seguridad. No apruebes el gate por tu cuenta.
4. Declara qué rutas revisaste, aunque no haya hallazgo.
