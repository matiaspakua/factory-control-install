# @aguvoda/factory-core

Instala el Factory CORE (el proceso AI-DLC como código) en tu repositorio:

```bash
npx @aguvoda/factory-core@latest init
```

Requiere Node.js 22 o superior.
